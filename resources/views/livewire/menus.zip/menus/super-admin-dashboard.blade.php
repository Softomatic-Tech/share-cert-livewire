<div>
    <h1 class="text-xl font-bold">Super Admin Dashboard</h1>
    <div class="grid gap-4 md:grid-cols-3">
        <div class="border p-4">User Content 1</div>
        <div class="border p-4">User Content 2</div>
        <div class="border p-4">User Content 3</div>
    </div>
</div>
